<?php

/***
--------------------------------------------------------------------------------
An Easy GuestBook 0.2
     
	 This file is part of An Easy GuestBook.

    An Easy GuestBook is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    An Easy GuestBook is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with An Easy GuestBook; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


This program is provided under the GNU/GPL license.
See LICENSE file for more informations

Website: http://www.students3k.com
Author: Karthikh Venkat


--------------------------------------------------------------------------------
*/
/// Defines class to handle database connections and queries.


class db {
    protected $conn;
    function __construct($host, $user, $password, $db_name){
	  $this->conn = new mysqli($host, $user, $password, $db_name)
	                or die($this->conn->error);
    }

    /// Execute SQL query.
    function query($sql) {
		//print"<br>$sql<br>";
        return $this->conn->query($sql);
    }

    /// Return number of rows in result.
    function num_rows($query_result) {
        return $query_result->num_rows;
    }

    /// Return result as an object.
    function fetch_result($query_result) {
        return $query_result->fetch_assoc();
    }

    function __destruct(){
        $this->conn->close();
    }
}
?>