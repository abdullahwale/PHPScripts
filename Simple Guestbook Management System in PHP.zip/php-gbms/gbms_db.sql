-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2022 at 06:29 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `gbms_db`
--
CREATE DATABASE IF NOT EXISTS `gbms_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `gbms_db`;

-- --------------------------------------------------------

--
-- Table structure for table `entry_detail`
--

CREATE TABLE `entry_detail` (
  `entry_id` int(11) NOT NULL,
  `entry_author` varchar(50) NOT NULL DEFAULT '',
  `entry_dob` varchar(50) NOT NULL DEFAULT '',
  `entry_email` varchar(100) NOT NULL DEFAULT '',
  `entry_url` varchar(100) NOT NULL DEFAULT '',
  `entry_location` varchar(50) NOT NULL DEFAULT '',
  `entry_date` datetime NOT NULL DEFAULT current_timestamp(),
  `entry_comments` text NOT NULL,
  `entry_referer` varchar(50) NOT NULL DEFAULT '',
  `entry_ip` varchar(15) NOT NULL DEFAULT '',
  `entry_hidden` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `entry_detail`
--

INSERT INTO `entry_detail` (`entry_id`, `entry_author`, `entry_dob`, `entry_email`, `entry_url`, `entry_location`, `entry_date`, `entry_comments`, `entry_referer`, `entry_ip`, `entry_hidden`) VALUES
(6, 'Claire Blake', '1998-06-23', 'cblake@mail.com', 'https://sourcecodester.com', 'Sample Location', '2022-12-19 11:55:27', 'Sample comment only', 'N/A', '::1', '0'),
(8, 'Mark D Cooper', '2001-10-14', 'mcooper@mail.com', 'http://google.com', 'Sample Location', '2022-12-19 11:57:37', 'Sample Comment 101', 'Passed by', '::1', '0'),
(22, 'Celene Casaletto', '1991-08-21', 'ccasaletto0@usatoday.com', 'http://yahoo.com/dapibus.json?mi=morbi&pede=vestibulum&malesuada=velit&in=id&imperdiet=pretium&et=ia', '91 Grayhawk Place', '2022-12-19 13:23:51', 'Vivamus tortor. Duis mattis egestas metus. Aenean fermentum.', 'risus semper porta volutpat quam pede lobortis lig', '75.230.20.169', '0'),
(23, 'Nyssa Schubbert', '1992-08-27', 'nschubbert1@netvibes.com', 'https://plala.or.jp/maecenas.html?sapien=faucibus&a=orci&libero=luctus&nam=et&dui=ultrices&proin=pos', '2 Arapahoe Plaza', '2022-12-19 13:23:51', 'Mauris lacinia sapien quis libero. Nullam sit amet turpis elementum ligula vehicula consequat.', 'eu orci mauris lacinia sapien quis libero nullam s', '148.131.159.176', '0'),
(24, 'Loretta Danilewicz', '1999-07-11', 'ldanilewicz2@miitbeian.gov.cn', 'https://sohu.com/non/interdum/in/ante/vestibulum/ante/ipsum.jsp?mi=quam&pede=fringilla&malesuada=rho', '4771 South Avenue', '2022-12-19 13:23:51', 'Nulla ut erat id mauris vulputate elementum. Nullam varius.', 'tincidunt lacus at velit vivamus vel nulla eget er', '113.52.205.249', '0'),
(25, 'Wade Triner', '1998-10-09', 'wtriner3@reuters.com', 'https://wikia.com/ut/erat/id/mauris.json?at=duis&lorem=bibendum&integer=morbi&tincidunt=non&ante=qua', '8964 Golf View Parkway', '2022-12-19 13:23:51', 'Etiam faucibus cursus urna. Ut tellus.', 'vitae quam suspendisse potenti nullam porttitor la', '7.17.98.43', '0'),
(26, 'Willa Cholton', '2000-05-10', 'wcholton4@parallels.com', 'https://taobao.com/quis/orci.json?interdum=metus&eu=aenean&tincidunt=fermentum&in=donec&leo=ut&maece', '1 Shoshone Street', '2022-12-19 13:23:51', 'Nullam porttitor lacus at turpis. Donec posuere metus vitae ipsum. Aliquam non mauris.', 'convallis duis consequat dui nec nisi volutpat ele', '94.191.118.163', '0'),
(27, 'Kassia Ruddlesden', '1995-01-24', 'kruddlesden5@feedburner.com', 'https://google.com/rhoncus/sed/vestibulum/sit.jpg?aliquam=velit&sit=vivamus&amet=vel&diam=nulla&in=e', '5 Scott Pass', '2022-12-19 13:23:51', 'Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci.', 'amet consectetuer adipiscing elit proin risus prae', '200.104.228.15', '0'),
(28, 'Holmes Fulstow', '1996-03-30', 'hfulstow6@unc.edu', 'https://elpais.com/orci/luctus/et.html?ac=in&nulla=est&sed=risus&vel=auctor&enim=sed&sit=tristique&a', '096 Darwin Plaza', '2022-12-19 13:23:51', 'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi.', 'felis ut at dolor quis odio consequat varius integ', '202.179.17.56', '0'),
(29, 'Danika Carrington', '1999-03-24', 'dcarrington7@so-net.ne.jp', 'http://slate.com/vestibulum.json?pede=nibh&ac=in&diam=hac&cras=habitasse&pellentesque=platea&volutpa', '693 Oak Valley Park', '2022-12-19 13:23:52', 'Morbi ut odio. Cras mi pede, malesuada in, imperdiet et, commodo vulputate, justo. In blandit ultrices enim.', 'lacus at turpis donec posuere metus vitae ipsum al', '23.109.214.98', '0'),
(30, 'Thaddus Longwood', '1994-02-15', 'tlongwood8@walmart.com', 'http://google.nl/donec/pharetra/magna/vestibulum/aliquet/ultrices/erat.html?dolor=in&sit=consequat&a', '4636 Southridge Crossing', '2022-12-19 13:23:52', 'Fusce consequat.', 'nisi at nibh in hac habitasse platea dictumst aliq', '204.89.118.6', '0'),
(31, 'Cher Dipple', '1995-09-20', 'cdipple9@live.com', 'http://fastcompany.com/tellus/nisi/eu/orci.jsp?pellentesque=ut&eget=tellus&nunc=nulla&donec=ut&quis=', '33 Del Mar Trail', '2022-12-19 13:23:52', 'Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros. Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue.', 'vestibulum rutrum rutrum neque aenean auctor gravi', '91.161.68.9', '0'),
(32, 'Booth Bischoff', '2000-10-15', 'bbischoffa@un.org', 'https://networkadvertising.org/interdum.aspx?maecenas=vel', '53 Commercial Center', '2022-12-19 13:23:52', 'Integer tincidunt ante vel ipsum.', 'malesuada in imperdiet et commodo vulputate justo ', '8.96.138.80', '0'),
(33, 'Celestyna Andriessen', '1998-03-09', 'candriessenb@hibu.com', 'https://paginegialle.it/consequat.xml?iaculis=turpis&justo=integer&in=aliquet&hac=massa&habitasse=id', '84 Ramsey Street', '2022-12-19 13:23:52', 'In sagittis dui vel nisl. Duis ac nibh.', 'cras non velit nec nisi vulputate nonummy maecenas', '134.139.64.18', '0'),
(34, 'Conny Pancost', '1997-01-14', 'cpancostc@arizona.edu', 'https://amazon.de/pretium/iaculis/diam/erat.png?non=iaculis&quam=justo&nec=in&dui=hac&luctus=habitas', '50761 Carioca Trail', '2022-12-19 13:23:52', 'Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet.', 'pretium nisl ut volutpat sapien arcu sed augue ali', '59.255.252.57', '0'),
(35, 'Cos Cristofvao', '1998-03-19', 'ccristofvaod@cdc.gov', 'http://tiny.cc/tempus/vel/pede/morbi/porttitor/lorem/id.jpg?eros=quis&viverra=libero&eget=nullam&con', '6993 Anniversary Plaza', '2022-12-19 13:23:52', 'Etiam faucibus cursus urna.', 'lacus morbi sem mauris laoreet ut rhoncus aliquet ', '221.106.23.21', '0'),
(36, 'Lyndel Frankom', '1995-04-14', 'lfrankome@mac.com', 'http://yandex.ru/purus/phasellus/in.jpg?convallis=congue&duis=elementum&consequat=in&dui=hac&nec=hab', '378 Stone Corner Hill', '2022-12-19 13:23:52', 'Nulla tempus. Vivamus in felis eu sapien cursus vestibulum. Proin eu mi.', 'aliquam convallis nunc proin at turpis a pede posu', '227.51.133.252', '0'),
(37, 'Georgeta McIlroy', '1999-06-28', 'gmcilroyf@bravesites.com', 'http://cocolog-nifty.com/aliquet/massa.json?pellentesque=magna&eget=ac&nunc=consequat&donec=metus&qu', '48 Carpenter Court', '2022-12-19 13:23:52', 'Nulla neque libero, convallis eget, eleifend luctus, ultricies eu, nibh. Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est.', 'ante vivamus tortor duis mattis egestas metus aene', '241.159.231.222', '0'),
(38, 'Guillemette Pawelek', '1994-07-13', 'gpawelekg@mapy.cz', 'https://reference.com/dis/parturient/montes/nascetur/ridiculus.json?donec=in&quis=porttitor&orci=ped', '56 Almo Drive', '2022-12-19 13:23:52', 'Morbi non quam nec dui luctus rutrum.', 'id turpis integer aliquet massa id lobortis conval', '58.242.54.128', '0'),
(39, 'Vivian Cicutto', '1999-10-26', 'vcicuttoh@wufoo.com', 'http://paginegialle.it/ac/tellus/semper/interdum/mauris.html?nullam=in&varius=purus&nulla=eu&facilis', '81189 Orin Junction', '2022-12-19 13:23:52', 'Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros. Vestibulum ac est lacinia nisi venenatis tristique. Fusce congue, diam id ornare imperdiet, sapien urna pretium nisl, ut volutpat sapien arcu sed augue.', 'metus sapien ut nunc vestibulum ante ipsum primis ', '87.163.200.213', '0'),
(40, 'Rosie Abbatt', '1992-01-15', 'rabbatti@acquirethisname.com', 'https://domainmarket.com/sit/amet/nulla/quisque/arcu.js?eget=viverra&nunc=pede&donec=ac&quis=diam&or', '34 Anniversary Plaza', '2022-12-19 13:23:52', 'Aliquam non mauris. Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet.', 'ut dolor morbi vel lectus in quam fringilla rhoncu', '153.62.176.86', '0'),
(41, 'Donia Kender', '1996-05-19', 'dkenderj@imgur.com', 'https://sbwire.com/quis/tortor/id.aspx?turpis=justo&elementum=in&ligula=blandit&vehicula=ultrices&co', '76 Orin Parkway', '2022-12-19 13:23:52', 'Cras in purus eu magna vulputate luctus.', 'a pede posuere nonummy integer non velit donec dia', '235.230.65.143', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `entry_detail`
--
ALTER TABLE `entry_detail`
  ADD PRIMARY KEY (`entry_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `entry_detail`
--
ALTER TABLE `entry_detail`
  MODIFY `entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
COMMIT;
