<?php 
class GuestBook {
	//Total number of entries in guestbook this number is updated everytime new entry is added or deleted
		

		var $total=0;


		var $entry_id=0;
		var $entry_author='';
		var $entry_email='';
		var $entry_url='http://';
		var $entry_dob;
		var $entry_location;
		var $referer='';
		var $entry_date;
		var $entry_comments='';
		var $entry_ip='0.0.0.0';
		var $entry_hidden='0'; 
			/* this variable is used to hide, unhide a specific entry.
				by default the entry is viewable to everybody */
		
        function __construct() {
			// constructor can be used later
				$this->update_total();
			

		}
		



		function update_total() {
			$sql="SELECT * from ".ENTRY_TABLE." WHERE entry_hidden='0'";
			$this->total=$GLOBALS["db"]->num_rows($GLOBALS["db"]->query($sql));

		}

	    function get($field) {
			return($this->$field);
        }  

        function set($field,$value) {
			$this->$field=$value;
        }
		 

        function retrieve_entry($id) {
			$sql="select * from ".ENTRY_TABLE." where entry_id=".$id;
			$result=$GLOBALS["db"]->query($sql);
            if($result && ($GLOBALS["db"]->num_rows($result)==1 )) {
				$data=$GLOBALS["db"]->fetch_result($result);
				$this->entry_id=$data['entry_id'];
 	            $this->entry_dob=$data['entry_dob'];
        		$this->entry_location=$data['entry_location'];
  		        $this->entry_author=$data['entry_author'];
				$this->entry_email=$data['entry_email'];
				$this->entry_url=$data['entry_url'];
				$this->entry_comments=$data['entry_comments'];
				$this->entry_date=$data['entry_date'];
				$this->referer=$data['entry_referer'];
				$this->entry_ip=$data['entry_ip'];
				$this->entry_hidden=$data['entry_hidden'];
				return true;
								
			} else {
					// no entry with such id exist
					return false;

     		}
			return false;

		}

         	
 





	

		
		function display_n_entries($start=-1,$end=-1) {
        /* This function can be used to display all the entries in the guestbook
           or can be called with proper $start and $end values to return only 
           specific no. of entries.
           when called with $start =-1 & $end =-1 will display all the entries
           on a single page 
           */
		    
		    
		    
		    // print "inside display n entries";
		    if($start==-1 && $end==-1) {
		        
		        
			$sql= "Select * from ".ENTRY_TABLE." where entry_hidden='0' ORDER BY ENTRY_DATE desc";	
		    
		    } 
		    else {
		       $sql= "Select * from ".ENTRY_TABLE." where entry_hidden='0' ORDER BY ENTRY_DATE desc limit $start, $end";	 
		        
		    }
		   // print "<br>$sql<br>";
			$result=$GLOBALS['db']->query($sql);
		    print("<div class='row justify-content-center'>\n");
		      
		          $class="even";
			while($data=$GLOBALS['db']->fetch_result($result)) {
			?>
				<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 px-2 py-1">
					<div class="card rounded-0 shadow">
						<div class="card-body rounded-0">
							<div class="container">
								<dl>
									<dt class="text-muted">Name</dt>
									<dd><?= $data['entry_author'] ?></dd>
								</dl>
								<dl>
									<dt class="text-muted">Birthday</dt>
									<dd><?= date("F d, Y", strtotime($data['entry_dob'])) ?></dd>
								</dl>
								<dl>
									<dt class="text-muted">Email</dt>
									<dd><a href="mailto:<?= $data['entry_email'] ?>"  target="_blank"><?= $data['entry_email'] ?></a></dd>
								</dl>
								<dl>
									<dt class="text-muted">Location</dt>
									<dd><?= $data['entry_location'] ?></dd>
								</dl>
								<dl>
									<dt class="text-muted">Knew this site from</dt>
									<dd><?= $data['entry_referer'] ?></dd>
								</dl>
								<dl>
									<dt class="text-muted">Website</dt>
									<dd class="text-truncate"><a href="<?= $data['entry_url'] ?>" target="_blank"><?= $data['entry_url'] ?></a></dd>
								</dl>
								<dl>
									<dt class="text-muted">Message/Comment</dt>
									<dd><?= $data['entry_comments'] ?></dd>
								</dl>
							</div>
						</div>
					</div>
				</div>
			<?php
				
			}
            print"     </div>\n";



		}

		function delete_entry($id) {
		// function to delete an entry
				
				$sql="delete from ".ENTRY_TABLE." where entry_id=".$id;
				if($GLOBALS["db"]->query($sql)) 
			   { 
					$this->update_total();
					return true;
					
			   } else {
				   $this->update_total();
				   return false;
               }
         }
  
		function add_entry() {
				
		    // update existing user's data
		    // do not use update() had password been changed,
			// instead, use password()
			
			$sql = "INSERT INTO ".ENTRY_TABLE." "
					." (entry_author,entry_dob, entry_email, entry_url, entry_location, entry_date, entry_comments, entry_referer,entry_ip,entry_hidden) "
					." VALUES ( '{$this->entry_author}',
								'{$this->entry_dob}',
								'{$this->entry_email}',
							   	'{$this->entry_url}',
								'{$this->entry_location}',
					     		NOW(),
								'{$this->entry_comments}',
								'{$this->referer}',
								'{$this->entry_ip}',
								'{$this->entry_hidden}'
							 ) ";
				//print "\n$sql\n";

				$GLOBALS["db"]->query($sql);
				$this->update_total();
		 }
			
		
		function hide_entry($id) {
				$ret=false;
				$sql = "update ".ENTRY_TABLE."	set entry_hidden='1' where entry_id=".$id;
				if($GLOBALS['db']->query($sql)) {
					$ret=true;
					$this->update_total();
				}
				return $ret;
	

		}
		
		function unhide_entry($id) {
				$ret=false;
				$sql = "update ".ENTRY_TABLE."	set entry_hidden='0' where entry_id=".$id;
				if($GLOBALS['db']->query($sql)) {
					$ret=true;
					$this->update_total();
				} 
				return $ret;


		}



		function modify_entry() {
			
			$sql = "UPDATE ".ENTRY_TABLE." "
				 . " SET"
			  	 . " entry_dob = '$this->entry_dob',"
                 . " entry_location = '$this->entry_location',"
                 . " entry_author = '$this->entry_author',"
				 . " entry_url = '$this->entry_url',"
			     . " entry_comments = '$this->entry_comments',"
				 . " entry_email = '$this->entry_email',"
			     . " entry_referer = '$this->referer'"
				 . " where entry_id=$this->entry_id";
			//print"<BR>$sql<br>";
				$GLOBALS["db"]->query($sql);
		}	
	
		function display_add_form($error="") {
			if(trim($error)!="") {
				print"<div class='error'>Please correct following errors:<br>$error</div>\n";

			}
			//print"this is the add form total current entries = ".$GLOBALS["gb"]->total;
			?>
			<div class="col-lg-6 col-md-8 col-sm-12 col-xs-12 mx-auto">
			<div class="card rounded-0 mb-3">
				<div class="card-header">
					<div class="card-title"><b>New Guest Data</b></div>
				</div>
				<div class="card-body">
					<div class="container-fluid">
						<form id="update-form" method="POST" action="<?= $_SERVER['PHP_SELF'] ?>">
							<input type="hidden" name="submit" value="Submit">
							<div class="mb-3">
								<label for="entry_name" class="form-label">Name</label>
								<input type="text" id="entry_name" name="entry_name" class="form-control form-control-sm rounded-0" value="<?= $this->entry_author ?>" required>
							</div>
							<div class="mb-3">
								<label for="entry_email" class="form-label">Email</label>
								<input type="email" id="entry_email" name="entry_email" class="form-control form-control-sm rounded-0" value="<?= $this->entry_email ?>" required>
							</div>
							<div class="mb-3">
								<label for="entry_referer" class="form-label">Referrer</label>
								<input type="text" id="entry_referer" name="entry_referer" class="form-control form-control-sm rounded-0" value="<?= $this->referer ?>" required>
							</div>
							<div class="mb-3">
								<label for="entry_dob" class="form-label">Birthday</label>
								<input type="date" id="entry_dob" name="entry_dob" class="form-control form-control-sm rounded-0" value="<?= $this->entry_dob ?>" required>
							</div>
							<div class="mb-3">
								<label for="entry_location" class="form-label">Location</label>
								<input type="text" id="entry_location" name="entry_location" class="form-control form-control-sm rounded-0" value="<?= $this->entry_location ?>" required>
							</div>
							<div class="mb-3">
								<label for="entry_website" class="form-label">Website</label>
								<input type="text" id="entry_website" name="entry_website" class="form-control form-control-sm rounded-0" value="<?= $this->entry_url ?>" required>
							</div>
							<div class="mb-3">
								<label for="entry_comments" class="form-label">Comments</label>
								<textarea rows="3" id="entry_comments" name="entry_comments" class="form-control form-control-sm rounded-0" required><?= $this->entry_comments ?></textarea>
							</div>
						</form>
					</div>
				</div>
				<div class="card-footer rounded-0 text-center py-2">
					<button class="btn btn-dm rounded-0 btn-primary rounded-0"form="update-form"><i class="fa fa-save"></i> Save</button>
					<a href="./" class="btn btn-dm rounded-0 btn-default border rounded-0">Cancel</a>
				</div>
			</div>
		</div>
			<?php
		}
		
}
?>
