<?php 
require_once("config.php");
require_once("gb.php");
require_once("db.class.php");
//session_save_path("../tmp/");
@session_start();
	// print_r($_SESSION);exit;
	function admin_header() {
		ob_start();
		include_once("header.php");
		return ob_get_clean();
	    
	    
	}
	$action=(isset($_GET['action'])) ? $_GET['action'] : "";
	
    //session_save_path("tmp/");
    if($action=='logout') {
        unset($login);
        session_destroy();
        header('location:admin.php');
		exit;
    }
	
	
	$message="";
    if(isset($_SESSION['login'])){
		echo admin_header();
		$db=new db($db_host,$db_user,$db_passwd,$db_database); 
		$admin_gb=new GuestBook();
		if($action=='delete') {
			$admin_gb->delete_entry($_GET['delete']);
			echo "<script> alert('Guest Data has been deleted successfully.'); location.replace('admin.php'); </script>";
			exit;
		}
		if($action=="edit") {
			$id=$_GET['edit'];
			$admin_gb->retrieve_entry($id);
		?>
		<div class="col-lg-6 col-md-8 col-sm-12 col-xs-12 mx-auto">
			<div class="card rounded-0 mb-3">
				<div class="card-header">
					<div class="card-title"><b>Update Guest Data</b></div>
				</div>
				<div class="card-body">
					<div class="container-fluid">
						<form id="update-form" method="POST" action="<?= $_SERVER['PHP_SELF'] ?>">
							<input type="hidden" name="id" value="<?= $id ?>">
							<input type="hidden" name="submit" value="update">
							<div class="mb-3">
								<label for="entry_author" class="form-label">Name</label>
								<input type="text" id="entry_author" name="entry_author" class="form-control form-control-sm rounded-0" value="<?= $admin_gb->entry_author ?>" required>
							</div>
							<div class="mb-3">
								<label for="entry_email" class="form-label">Email</label>
								<input type="email" id="entry_email" name="entry_email" class="form-control form-control-sm rounded-0" value="<?= $admin_gb->entry_email ?>" required>
							</div>
							<div class="mb-3">
								<label for="entry_referer" class="form-label">Referrer</label>
								<input type="text" id="entry_referer" name="entry_referer" class="form-control form-control-sm rounded-0" value="<?= $admin_gb->referer ?>" required>
							</div>
							<div class="mb-3">
								<label for="entry_dob" class="form-label">Birthday</label>
								<input type="date" id="entry_dob" name="entry_dob" class="form-control form-control-sm rounded-0" value="<?= $admin_gb->entry_dob ?>" required>
							</div>
							<div class="mb-3">
								<label for="entry_location" class="form-label">Location</label>
								<input type="text" id="entry_location" name="entry_location" class="form-control form-control-sm rounded-0" value="<?= $admin_gb->entry_location ?>" required>
							</div>
							<div class="mb-3">
								<label for="entry_website" class="form-label">Website</label>
								<input type="text" id="entry_website" name="entry_website" class="form-control form-control-sm rounded-0" value="<?= $admin_gb->entry_url ?>" required>
							</div>
							<div class="mb-3">
								<label for="entry_comments" class="form-label">Comments</label>
								<textarea rows="3" id="entry_comments" name="entry_comments" class="form-control form-control-sm rounded-0" required><?= $admin_gb->entry_comments ?></textarea>
							</div>
						</form>
					</div>
				</div>
				<div class="card-footer rounded-0 text-center py-2">
					<button class="btn btn-dm rounded-0 btn-primary rounded-0"form="update-form"><i class="fa fa-save"></i> Update</button>
					<a href="admin.php" class="btn btn-dm rounded-0 btn-default border rounded-0" form="update-form">Cancel</a>
				</div>
			</div>
		</div>
		<?php
		  unset($edit);
	    } 
		 $submit=(isset($_POST['submit'])) ? $_POST['submit'] : '';
		 switch(strtolower($submit)) {
			case "update":
 				$admin_gb->entry_id=$_POST['id'];
				$admin_gb->entry_dob=$_POST['entry_dob'];
				$admin_gb->entry_location=$_POST['entry_location'];
				$admin_gb->entry_author=$_POST['entry_author'];
				$admin_gb->entry_email=$_POST['entry_email'];
				$admin_gb->entry_url=$_POST['entry_website'];
				$admin_gb->entry_comments=$_POST['entry_comments'];
				$admin_gb->referer=$_POST['entry_referer'];
				if($admin_gb->modify_entry()) {
					$message="Selected Entry Modified Succesfully";
				} else {
					$message="Error while updating selected Entry";
				}
				break;
			default:
			}
			



		
		
		$sql = "Select * from ".ENTRY_TABLE." 	order by entry_date DESC";
		$result = $db->query($sql);
	  	if($admin_gb->total >0){
		?>
			<table class='table table-bordered table-striped'>
			<thead>
				<tr class='admin_list_top'>
					<th class="text-center">Name</th>
					<th class="text-center">Email</th>
					<th class="text-center">Location</th>
					<th class="text-center">Date Signed</th>
					<th class="text-center">Comments</th>
					<th class="text-center">IP Address</th>
					<th class="text-center">Action</th>
				</tr>
			</thead>
			<?php
			while($data=$db->fetch_result($result)) {
				?>
				
				    <tr class='admin_list_data'>
				       	<td class="p-1">
							<?= ($data['entry_author']) ?>
				  	 	</td>
				       	<td class="p-1">
							<?= ($data['entry_email']) ?> 
				       	</td>
				       	<td class="p-1">
							<?= ($data['entry_location']) ?> 
				       	</td>
				       	<td class="p-1">
							<?= ($data['entry_date']) ?>
						</td>
				       	<td class="p-1">
							<?= ($data['entry_comments']) ?>
				       	</td>
				       	<td class="p-1">
							<?= ($data['entry_ip']) ?>
				       	</td>
					   	<td class="p-1">
							<div class="btn-group btn-group-sm">
								<a href='<?= $_SERVER['PHP_SELF']."?action=edit&edit=".$data['entry_id'] ?>' class='btn btn-sm btn-outline-primary rounded-0'><i class="fa fa-edit" title="Edit"></i></a>
								<a href='<?= $_SERVER['PHP_SELF']."?action=delete&delete=".$data['entry_id'] ?>' class='btn btn-sm btn-outline-danger rounded-0'><i class="fa fa-trash" title="Delete"></i></a>
						  </div>
				       	</td>
				    </tr>
			<?php	
			}  
			?>
		
			</table>
	<?php
		}else {
	?>
			<div class="text-center">
				<span class="text-danger">No data found</span>
			</div>
	<?php
		}  
	
	} else {
            
            
			if(isset($_POST['submit']) && $_POST['submit']=="Login") {
			    $login=$_POST['login'];
                $password=$_POST['password'];
				// print_r(["login" => $admin_login, "password" => $admin_password, "e_login" => $login, "e_password" => $password]); exit;
                if($login==$admin_login && $password==$admin_password) { 
                    @session_start();
		            $_SESSION['login']="$login";
		            header("Location:admin.php?code=1");
					exit;
                 } else { 
				     header("Location:admin.php?code=4");
					 exit;
				 }
                
                
        }  else {
                
				
                echo admin_header();
				if(isset($code) && $code==4)
					print("<font color='red'><b>Invalid Id/Password </b></font>");
				?>
				<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 mx-auto">
					<div class="card rounded-0">
						<div class="card-header rounded-0">
							<div class="card-title text-center">Adminstrator Login</div>
						</div>
						<div class="card-body rounded-0">
							<div class="container-fluid">
								<form id="login-form" action="admin.php" method="POST">
									<div class="mb-3">
										<label for="login" class="form-label">Username</label>
										<input type="text" id="login" autofocus name="login" class="form-control rounded-0" required>
									</div>
									<div class="mb-3">
										<label for="password" class="form-label">Password</label>
										<input type="password" id="password" name="password" class="form-control rounded-0" required>
									</div>
									<div class="mb-3 text-end">
										<input type="submit" class="btn btn-primary rounded-0" value="Login" name="submit">
									</div>
									<div class="text-center">
										<a href="./">Public Site</a>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<?php
            }
            
        }
?>   
	</div>
	<!-- End of Container -->
	</body>
</html> 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
